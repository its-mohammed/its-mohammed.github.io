# Naughty Squirrel

Using chrome to get the best performance.
[Here to PLAY!](http://bufferspace.github.com/NaughtySquirrel/)

We have to clear that the name means nothing...and it's kind of stupid...

This game is inspired by TEMPLE RUN. More specifically, this game is a 2D version of temple run. The game is developped for pure fun. But one of the serious reason is to see the performance of HTML5 and Cocos2D HTML. Obviously, the performance is not that good and you may feel dazzling not because of the speed of the game but the bad performance.

## Rules

+ You have 3 HP at the very beginning.
+ Invalid turning decreases your HP by 1.
+ If you failed to jump in some specific landscape, game over.
+ If you failed to turn in turnings, game over.
+ If you don't have any HP, game over.

## Score

+ Each golden bean worths 1 point.
+ The running distance keeps increasing.
+ The total score is the combination of the above points.

## Operations

+ a：Slide left.
+ d：Slide right.
+ ←：Turn left.
+ →：Turn right.
+ ↑：Jump.

## Properties

+ Ruby: In the following 500 meters, score is doubled.
+ Saphire: In the following 500 meters, score is tripled.
+ magnet: Absorbe golden beans for you.
+ medicine: Heal 1 HP.

## LICENCE

(The MIT License)

Copyright (c) 2012 by [Zero](https://github.com/Aquietzero) and [fsiaonma](https://github.com/fsiaonma)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the 'Software'), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
