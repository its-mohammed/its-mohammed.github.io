// Coin trophy
var Coin = {

	value: 1,
	src: P_COIN,

  reset: function() {

    this.value = 1;
    this.src = P_COIN;

  },

};

