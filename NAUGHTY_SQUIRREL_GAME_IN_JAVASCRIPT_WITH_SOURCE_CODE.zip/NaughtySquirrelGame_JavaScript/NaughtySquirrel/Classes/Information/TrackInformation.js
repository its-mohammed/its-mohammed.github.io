
var TrackInformation = {

  basicTrophyType: Coin,

};