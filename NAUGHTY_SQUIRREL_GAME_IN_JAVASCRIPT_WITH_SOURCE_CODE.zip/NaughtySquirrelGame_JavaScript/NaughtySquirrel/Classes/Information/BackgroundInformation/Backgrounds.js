
var Background1 = {

  src: P_BACKGROUND_1,
  velocity: 200,

}

var Background2 = {

  src: P_BACKGROUND_2,
  velocity: 100,

}
