
var TrophiesController = {

  reset: function() {

    Coin.reset();

  },
  
}